import numpy as np
import pandas as pd

file_path = 'metr-la.h5'
df=pd.read_hdf(file_path)
traffic_speed = df.values
# np.savez('metr_la.npz', data=traffic_speed)
datas = np.load('metr_la.npz')
print(datas.files)
print(datas['data'])
print(datas['data'].shape)
